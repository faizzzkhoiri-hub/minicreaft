[app]
title = MiniCraft Mobile
package.name = minicraftmobile
package.domain = org.minicraft
source.dir = .
source.include_exts = py,png,jpg,jpeg,wav,ogg,json,ttf
version = 3.0.0
requirements = python3,pygame
orientation = landscape
fullscreen = 1
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
