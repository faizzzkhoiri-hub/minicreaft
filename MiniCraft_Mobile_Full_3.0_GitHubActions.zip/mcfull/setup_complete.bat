@echo off
echo Installing dependencies for Minecraft Complete Edition...
pip install pygame numpy

echo.
echo Building game to executable...
pip install pyinstaller

pyinstaller --onefile --windowed --name "Minecraft_Complete" --icon NONE minecraft_complete.py

echo.
echo Done! Your game is ready in the 'dist' folder!
echo To run: double-click Minecraft_Complete.exe
echo.
echo World saves will be stored in: saves/ folder
pause
