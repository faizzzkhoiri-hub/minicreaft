# MiniCraft Mobile 3.0

Android-first voxel sandbox prototype with original UI.

## Controls
- WASD: move
- Mouse/touch drag: look
- Space / J: jump
- Left/M: mine
- Right/P: place
- E/I: inventory
- C: crafting
- 1-9: hotbar
- F: place

## Android build
On Linux/WSL with Buildozer:

    pip install buildozer cython
    buildozer android debug

The generated APK will be placed in `bin/`.

## Important
This is an original voxel sandbox project. It does not include Mojang/Minecraft assets or branding. It is not a literal 100% copy of Minecraft. A production-quality 3D mobile game still needs native/OpenGL chunk meshing, texture atlases, audio assets, more advanced AI, and extensive device testing.


## Build APK langsung dari HP Android

Proyek ini sudah menyertakan workflow GitHub Actions di `.github/workflows/build-apk.yml`. Upload proyek ke GitHub, buka **Actions → Build MiniCraft APK → Run workflow**, lalu download artifact `MiniCraft-Mobile-debug-apk`. Lihat `README_GITHUB_ACTIONS.md` untuk langkah lengkap.
