# MiniCraft Mobile — Build APK dari HP

Workflow GitHub Actions sudah disiapkan di:

`.github/workflows/build-apk.yml`

## Cara build dari HP Android

1. Buat repository baru di GitHub.
2. Upload seluruh isi folder proyek ini ke repository.
3. Buka tab **Actions**.
4. Pilih **Build MiniCraft APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai job selesai.
7. Buka hasil workflow dan cari bagian **Artifacts**.
8. Download `MiniCraft-Mobile-debug-apk`.
9. Extract ZIP artifact tersebut, lalu install APK di HP.

Workflow juga otomatis berjalan ketika kamu membuat Git tag yang diawali `v`, misalnya `v3.0.0`.

## Catatan

- APK yang dihasilkan adalah **debug APK** untuk pengujian.
- Jangan memasukkan ke repository keystore/password pribadi.
- Build pertama bisa cukup lama karena Android SDK/NDK dan python-for-android perlu disiapkan.
- Proyek ini menggunakan UI dan aset original; bukan salinan aset Minecraft/Mojang.
